<?php
/**
 * Rally Point theme setup.
 *
 * @package rally-point
 */

defined( 'ABSPATH' ) || exit;

define( 'RALLY_POINT_VERSION', '1.0.0' );

add_action( 'after_setup_theme', function () {
	load_theme_textdomain( 'rally-point', get_template_directory() . '/languages' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'post-thumbnails' );
	add_editor_style( 'assets/css/theme.css' );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'rally-point', get_theme_file_uri( 'assets/css/theme.css' ), array(), RALLY_POINT_VERSION );
	wp_enqueue_script( 'rally-point', get_theme_file_uri( 'assets/js/theme.js' ), array(), RALLY_POINT_VERSION, array( 'strategy' => 'defer', 'in_footer' => true ) );
} );

add_action( 'init', function () {
	register_block_pattern_category( 'rally-point', array( 'label' => __( 'Rally Point sections', 'rally-point' ) ) );
	register_block_style( 'core/group', array( 'name' => 'dark-section', 'label' => __( 'Dark section', 'rally-point' ) ) );
	register_block_style( 'core/group', array( 'name' => 'card', 'label' => __( 'Card', 'rally-point' ) ) );
	register_block_style( 'core/group', array( 'name' => 'hide-section', 'label' => __( 'Hidden (not shown on site)', 'rally-point' ) ) );
} );

require get_theme_file_path( 'inc/contact-form.php' );

/**
 * On activation: create demo pages (once) using the theme's patterns and set the homepage.
 * Nothing is overwritten if pages already exist.
 */
add_action( 'after_switch_theme', function () {
	if ( get_option( 'rally_point_demo_created' ) ) {
		return;
	}
	$registry = WP_Block_Patterns_Registry::get_instance();
	$content  = function ( $slug ) use ( $registry ) {
		$pattern = $registry->get_registered( 'rally-point/' . $slug );
		return $pattern ? $pattern['content'] : '';
	};
	$simple = function ( $title, $text ) use ( $content ) {
		return $content( 'image-text' ) . "\n<!-- wp:paragraph -->\n<p>" . esc_html( $text ) . "</p>\n<!-- /wp:paragraph -->";
	};
	$pages = array(
		'Home'           => $content( 'homepage' ),
		'About'          => $content( 'intro' ) . $content( 'image-text' ) . $content( 'faq' ),
		'Attractions'    => $content( 'attractions' ) . $content( 'video' ),
		'Sponsors'       => $content( 'partners' ) . $content( 'cta' ),
		'Contact'        => $content( 'contact' ),
		'Privacy Policy' => "<!-- wp:paragraph -->\n<p>Replace this text with your privacy policy.</p>\n<!-- /wp:paragraph -->",
		'Terms'          => "<!-- wp:paragraph -->\n<p>Replace this text with your terms of use.</p>\n<!-- /wp:paragraph -->",
	);
	$ids = array();
	foreach ( $pages as $title => $body ) {
		$ids[ $title ] = wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => $title,
			'post_content' => $body,
		) );
	}
	if ( ! empty( $ids['Home'] ) && ! is_wp_error( $ids['Home'] ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $ids['Home'] );
	}
	update_option( 'rally_point_demo_created', 1 );
} );
