<?php
/**
 * Title: Sponsor CTA — Homepage
 * Slug: rally-point/cta
 * Categories: rally-point
 * Description: Contrasting call to action with three buttons.
 */
?>
<!-- wp:group {"metadata":{"name":"CTA — Homepage"},"align":"full","className":"rp-section rp-cta","layout":{"type":"constrained","wideSize":"1240px"}} -->
<div class="wp-block-group alignfull rp-section rp-cta"><!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Put your brand in front of 20,000 neighbors</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Sponsors get on-site presence, stage recognition and year-round promotion, with packages for every budget.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/sponsors">Sponsorship opportunities</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#contact">Become a partner</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#contact">Contact us</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
