<?php
/**
 * Title: Introduction — Homepage
 * Slug: rally-point/intro
 * Categories: rally-point
 * Description: Heading left, supporting text right.
 */
?>
<!-- wp:group {"metadata":{"name":"Introduction — Homepage"},"align":"full","className":"rp-section","layout":{"type":"constrained","wideSize":"1240px"}} -->
<div class="wp-block-group alignfull rp-section"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"45%"} -->
<div class="wp-block-column" style="flex-basis:45%"><!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Three days of music, food and neighbors</h2>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"55%"} -->
<div class="wp-block-column" style="flex-basis:55%"><!-- wp:paragraph -->
<p>Now in its tenth year, our festival gathers thousands of families for a weekend built around community, entertainment and giving back. Everyone is welcome, and every ticket funds local programs.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Expect headline concerts, a kids zone, regional food vendors and a closing fireworks show. Gates open at 10 a.m. each day.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/about">Read our story</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
