<?php
/**
 * Title: Mission — Homepage
 * Slug: rally-point/mission
 * Categories: rally-point
 * Description: Section heading and three editable support cards.
 */
?>
<!-- wp:group {"metadata":{"name":"Mission — Homepage"},"align":"full","backgroundColor":"background","className":"rp-section","layout":{"type":"constrained","wideSize":"1240px"}} -->
<div class="wp-block-group alignfull rp-section has-background-background-color has-background"><!-- wp:paragraph {"className":"rp-eyebrow"} -->
<p class="rp-eyebrow">Our mission</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Every ticket gives back</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>One clear sentence about where the money goes and why it matters. The three cards below show who it helps.</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"is-style-card rp-reveal","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card rp-reveal"><!-- wp:image {"className":"rp-icon","sizeSlug":"full"} -->
<figure class="wp-block-image size-full rp-icon"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-icon.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Veteran families</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Housing repairs and emergency support for veterans and their families in our county.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><a href="#">Learn more</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"is-style-card rp-reveal","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card rp-reveal"><!-- wp:image {"className":"rp-icon","sizeSlug":"full"} -->
<figure class="wp-block-image size-full rp-icon"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-icon.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">First responders</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Equipment grants and training funds for local fire, police and EMS teams.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><a href="#">Learn more</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"is-style-card rp-reveal","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card rp-reveal"><!-- wp:image {"className":"rp-icon","sizeSlug":"full"} -->
<figure class="wp-block-image size-full rp-icon"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-icon.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Youth programs</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Scholarships and after-school programs for the next generation of community leaders.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><a href="#">Learn more</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
