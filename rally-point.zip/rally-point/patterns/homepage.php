<?php
/**
 * Title: Homepage — Full Layout
 * Slug: rally-point/homepage
 * Categories: rally-point
 * Description: Complete homepage. Insert into a blank page, then edit each section.
 */
?>
<!-- wp:pattern {"slug":"rally-point/hero"} /-->

<!-- wp:pattern {"slug":"rally-point/intro"} /-->

<!-- wp:pattern {"slug":"rally-point/mission"} /-->

<!-- wp:pattern {"slug":"rally-point/attractions"} /-->

<!-- wp:pattern {"slug":"rally-point/video"} /-->

<!-- wp:pattern {"slug":"rally-point/partners"} /-->

<!-- wp:pattern {"slug":"rally-point/cta"} /-->

<!-- wp:pattern {"slug":"rally-point/contact"} /-->
