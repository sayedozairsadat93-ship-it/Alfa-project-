<?php
/**
 * Title: FAQ — Accordion
 * Slug: rally-point/faq
 * Categories: rally-point
 * Description: Expandable questions and answers.
 */
?>
<!-- wp:group {"metadata":{"name":"FAQ"},"align":"full","className":"rp-section","layout":{"type":"constrained","wideSize":"1240px"}} -->
<div class="wp-block-group alignfull rp-section"><!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Good to know</h2>
<!-- /wp:heading -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Is parking available?</summary>
<!-- wp:paragraph -->
<p>Yes. Free lots open at 9 a.m. with a shuttle to the main gate.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Can I bring my kids?</summary>
<!-- wp:paragraph -->
<p>Absolutely. Children under 12 are free with a paying adult.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>What if it rains?</summary>
<!-- wp:paragraph -->
<p>The event runs rain or shine. Covered areas are available at both stages.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group -->
