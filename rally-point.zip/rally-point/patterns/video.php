<?php
/**
 * Title: Video + Text — Homepage
 * Slug: rally-point/video
 * Categories: rally-point
 * Description: YouTube/Vimeo embed beside text.
 */
?>
<!-- wp:group {"metadata":{"name":"Video — Homepage"},"align":"full","className":"rp-section is-style-dark-section","layout":{"type":"constrained","wideSize":"1240px"}} -->
<div class="wp-block-group alignfull rp-section is-style-dark-section"><!-- wp:columns {"align":"wide","verticalAlignment":"center"} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"58%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:58%"><!-- wp:embed {"url":"https://www.youtube.com/watch?v=aqz-KE-bpKQ","type":"video","providerNameSlug":"youtube","responsive":true,"className":"wp-embed-aspect-16-9 wp-has-aspect-ratio"} -->
<figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio"><div class="wp-block-embed__wrapper">
https://www.youtube.com/watch?v=aqz-KE-bpKQ
</div></figure>
<!-- /wp:embed --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"42%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:42%"><!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">See last year in 90 seconds</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Replace this sample video with your highlight reel. Paste a YouTube or Vimeo link into the video block, or swap it for an uploaded video.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#contact">Get tickets</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
