<?php
/**
 * Title: Hero — Homepage
 * Slug: rally-point/hero
 * Categories: rally-point
 * Description: Full-width hero: replace the background image or video, edit text and buttons.
 */
?>
<!-- wp:cover {"url":"<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-hero.svg' ) ); ?>","dimRatio":70,"overlayColor":"primary","minHeight":92,"minHeightUnit":"vh","contentPosition":"center left","align":"full","className":"rp-hero","metadata":{"name":"Hero — Homepage"}} -->
<div class="wp-block-cover alignfull has-custom-content-position is-position-center-left rp-hero" style="min-height:92vh"><span aria-hidden="true" class="wp-block-cover__background has-primary-background-color has-background-dim-70 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-hero.svg' ) ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:paragraph {"className":"rp-eyebrow"} -->
<p class="rp-eyebrow">Annual community festival · July 4 weekend</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"textColor":"surface"} -->
<h1 class="wp-block-heading has-surface-color has-text-color">A weekend that brings the whole town together</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"surface","fontSize":"large"} -->
<p class="has-surface-color has-text-color has-large-font-size">Live music, family activities and local food, with every ticket supporting local veterans and first responders.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#contact">Get tickets</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#attractions">See what's planned</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:paragraph -->
<p>Fairgrounds, Your City, ST · Friday to Sunday</p>
<!-- /wp:paragraph -->
</div></div>
<!-- /wp:cover -->
