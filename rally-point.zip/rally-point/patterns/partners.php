<?php
/**
 * Title: Partner Logos — Homepage
 * Slug: rally-point/partners
 * Categories: rally-point
 * Description: Logo grid. Replace, link or drag logos to reorder.
 */
?>
<!-- wp:group {"metadata":{"name":"Partner Logos — Homepage"},"align":"full","className":"rp-section","layout":{"type":"constrained","wideSize":"1240px"}} -->
<div class="wp-block-group alignfull rp-section"><!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">Powered by local businesses</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Thank you to the partners who make this weekend possible.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"align":"wide","className":"rp-logos","layout":{"type":"grid","minimumColumnWidth":"11rem"}} -->
<div class="wp-block-group alignwide rp-logos"><!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><a href="#"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-logo.svg' ) ); ?>" alt="Partner 1 logo (replace)"/></a></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><a href="#"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-logo.svg' ) ); ?>" alt="Partner 2 logo (replace)"/></a></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><a href="#"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-logo.svg' ) ); ?>" alt="Partner 3 logo (replace)"/></a></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><a href="#"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-logo.svg' ) ); ?>" alt="Partner 4 logo (replace)"/></a></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><a href="#"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-logo.svg' ) ); ?>" alt="Partner 5 logo (replace)"/></a></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><a href="#"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-logo.svg' ) ); ?>" alt="Partner 6 logo (replace)"/></a></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><a href="#"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-logo.svg' ) ); ?>" alt="Partner 7 logo (replace)"/></a></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><a href="#"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-logo.svg' ) ); ?>" alt="Partner 8 logo (replace)"/></a></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
