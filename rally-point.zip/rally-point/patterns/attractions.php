<?php
/**
 * Title: Attractions — Homepage
 * Slug: rally-point/attractions
 * Categories: rally-point
 * Description: Card grid: 3 columns desktop, 2 tablet, 1 phone.
 */
?>
<!-- wp:group {"metadata":{"name":"Attractions — Homepage"},"align":"full","className":"rp-section","layout":{"type":"constrained","wideSize":"1240px"}} -->
<div class="wp-block-group alignfull rp-section"><!-- wp:paragraph {"className":"rp-eyebrow"} -->
<p class="rp-eyebrow">What to expect</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"anchor":"attractions"} -->
<h2 class="wp-block-heading" id="attractions">Something for every age</h2>
<!-- /wp:heading -->

<!-- wp:group {"align":"wide","layout":{"type":"grid","minimumColumnWidth":"18rem"}} -->
<div class="wp-block-group alignwide"><!-- wp:group {"className":"is-style-card rp-reveal","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card rp-reveal"><!-- wp:image {"sizeSlug":"large","className":"rp-card-img"} -->
<figure class="wp-block-image size-large rp-card-img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-feature.svg' ) ); ?>" alt="Live music placeholder image"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"rp-tag"} -->
<p class="rp-tag">Music</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Live music</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Two stages, twelve acts and a closing headliner each night.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"is-style-card rp-reveal","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card rp-reveal"><!-- wp:image {"sizeSlug":"large","className":"rp-card-img"} -->
<figure class="wp-block-image size-large rp-card-img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-feature.svg' ) ); ?>" alt="Family zone placeholder image"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"rp-tag"} -->
<p class="rp-tag">Family</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Family zone</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Rides, games, face painting and a shaded rest area for parents.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"is-style-card rp-reveal","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card rp-reveal"><!-- wp:image {"sizeSlug":"large","className":"rp-card-img"} -->
<figure class="wp-block-image size-large rp-card-img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-feature.svg' ) ); ?>" alt="Food and drink placeholder image"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"rp-tag"} -->
<p class="rp-tag">Food</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Food and drink</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Local vendors, food trucks and a family-friendly beer garden.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"is-style-card rp-reveal","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card rp-reveal"><!-- wp:image {"sizeSlug":"large","className":"rp-card-img"} -->
<figure class="wp-block-image size-large rp-card-img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-feature.svg' ) ); ?>" alt="Vendor market placeholder image"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"rp-tag"} -->
<p class="rp-tag">Vendors</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Vendor market</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Handmade goods and small-business booths along Main Lawn.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"is-style-card rp-reveal","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card rp-reveal"><!-- wp:image {"sizeSlug":"large","className":"rp-card-img"} -->
<figure class="wp-block-image size-large rp-card-img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-feature.svg' ) ); ?>" alt="Fireworks placeholder image"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"rp-tag"} -->
<p class="rp-tag">Finale</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Fireworks</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A 20-minute finale over the lake on Sunday night.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"is-style-card rp-reveal","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card rp-reveal"><!-- wp:image {"sizeSlug":"large","className":"rp-card-img"} -->
<figure class="wp-block-image size-large rp-card-img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/placeholder-feature.svg' ) ); ?>" alt="Special experiences placeholder image"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"rp-tag"} -->
<p class="rp-tag">VIP</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Special experiences</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>VIP viewing decks, meet-and-greets and guided tours.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
