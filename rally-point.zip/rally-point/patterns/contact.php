<?php
/**
 * Title: Contact Form — Homepage
 * Slug: rally-point/contact
 * Categories: rally-point
 * Description: Inquiry form with contact details.
 */
?>
<!-- wp:group {"metadata":{"name":"Contact Form — Homepage"},"align":"full","backgroundColor":"background","className":"rp-section","layout":{"type":"constrained","wideSize":"1240px"}} -->
<div class="wp-block-group alignfull rp-section has-background-background-color has-background"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"40%"} -->
<div class="wp-block-column" style="flex-basis:40%"><!-- wp:heading {"level":2,"anchor":"contact"} -->
<h2 class="wp-block-heading" id="contact">Let's talk</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Questions about tickets, sponsorship or vending? Send a message and we will answer within two business days.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><a href="mailto:hello@example.com">hello@example.com</a><br><a href="tel:+15555550100">(555) 555-0100</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"60%"} -->
<div class="wp-block-column" style="flex-basis:60%"><!-- wp:shortcode -->
[rally_contact_form]
<!-- /wp:shortcode --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
