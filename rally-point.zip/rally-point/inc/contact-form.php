<?php
/**
 * Contact form: [rally_contact_form] shortcode + secure handler.
 * Sends to the site admin email (override with the `rally_point_form_recipient` filter).
 *
 * @package rally-point
 */

defined( 'ABSPATH' ) || exit;

function rally_point_inquiry_types() {
	return apply_filters( 'rally_point_inquiry_types', array(
		'general'     => __( 'General inquiry', 'rally-point' ),
		'sponsorship' => __( 'Sponsorship', 'rally-point' ),
		'vendor'      => __( 'Vendor registration', 'rally-point' ),
		'partnership' => __( 'Partnership', 'rally-point' ),
	) );
}

add_shortcode( 'rally_contact_form', function () {
	$status = isset( $_GET['rp_form'] ) ? sanitize_key( wp_unslash( $_GET['rp_form'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	ob_start();
	echo '<div class="rp-form-wrap">';
	if ( 'sent' === $status ) {
		echo '<p class="rp-form-msg rp-form-msg--ok" role="status">' . esc_html__( 'Thank you. Your message was sent and we will reply soon.', 'rally-point' ) . '</p>';
	} elseif ( 'error' === $status ) {
		echo '<p class="rp-form-msg rp-form-msg--err" role="alert">' . esc_html__( 'We could not send your message. Check the required fields and try again.', 'rally-point' ) . '</p>';
	}
	?>
	<form class="rp-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="rally_contact">
		<input type="hidden" name="rp_ts" value="<?php echo esc_attr( time() ); ?>">
		<?php wp_nonce_field( 'rally_contact', 'rp_nonce' ); ?>
		<p class="rp-hp" aria-hidden="true"><label>Leave empty <input type="text" name="rp_website" tabindex="-1" autocomplete="off"></label></p>
		<p><label for="rp-name"><?php esc_html_e( 'Name', 'rally-point' ); ?> <span aria-hidden="true">*</span></label>
			<input id="rp-name" name="rp_name" type="text" required autocomplete="name"></p>
		<p><label for="rp-email"><?php esc_html_e( 'Email', 'rally-point' ); ?> <span aria-hidden="true">*</span></label>
			<input id="rp-email" name="rp_email" type="email" required autocomplete="email"></p>
		<p><label for="rp-phone"><?php esc_html_e( 'Phone', 'rally-point' ); ?></label>
			<input id="rp-phone" name="rp_phone" type="tel" autocomplete="tel"></p>
		<p><label for="rp-org"><?php esc_html_e( 'Organization', 'rally-point' ); ?></label>
			<input id="rp-org" name="rp_org" type="text" autocomplete="organization"></p>
		<p><label for="rp-type"><?php esc_html_e( 'Inquiry type', 'rally-point' ); ?></label>
			<select id="rp-type" name="rp_type">
				<?php foreach ( rally_point_inquiry_types() as $key => $label ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select></p>
		<p><label for="rp-msg"><?php esc_html_e( 'Message', 'rally-point' ); ?> <span aria-hidden="true">*</span></label>
			<textarea id="rp-msg" name="rp_message" rows="5" required></textarea></p>
		<p class="rp-note"><?php esc_html_e( '* Required field', 'rally-point' ); ?></p>
		<p><button type="submit" class="wp-element-button"><?php esc_html_e( 'Send message', 'rally-point' ); ?></button></p>
	</form>
	<?php
	echo '</div>';
	return ob_get_clean();
} );

function rally_point_handle_form() {
	$back = wp_get_referer() ? remove_query_arg( 'rp_form', wp_get_referer() ) : home_url( '/' );
	$fail = add_query_arg( 'rp_form', 'error', $back ) . '#contact';

	if ( ! isset( $_POST['rp_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['rp_nonce'] ) ), 'rally_contact' ) ) {
		wp_safe_redirect( $fail );
		exit;
	}
	$ts = isset( $_POST['rp_ts'] ) ? absint( $_POST['rp_ts'] ) : 0;
	if ( ! empty( $_POST['rp_website'] ) || ( time() - $ts ) < 3 ) { // Bots: pretend success.
		wp_safe_redirect( add_query_arg( 'rp_form', 'sent', $back ) . '#contact' );
		exit;
	}
	$name  = isset( $_POST['rp_name'] ) ? sanitize_text_field( wp_unslash( $_POST['rp_name'] ) ) : '';
	$email = isset( $_POST['rp_email'] ) ? sanitize_email( wp_unslash( $_POST['rp_email'] ) ) : '';
	$phone = isset( $_POST['rp_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['rp_phone'] ) ) : '';
	$org   = isset( $_POST['rp_org'] ) ? sanitize_text_field( wp_unslash( $_POST['rp_org'] ) ) : '';
	$type  = isset( $_POST['rp_type'] ) ? sanitize_key( wp_unslash( $_POST['rp_type'] ) ) : 'general';
	$msg   = isset( $_POST['rp_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['rp_message'] ) ) : '';
	$types = rally_point_inquiry_types();

	if ( '' === $name || ! is_email( $email ) || '' === $msg || ! isset( $types[ $type ] ) ) {
		wp_safe_redirect( $fail );
		exit;
	}
	$to      = apply_filters( 'rally_point_form_recipient', get_option( 'admin_email' ) );
	$subject = sprintf( '[%s] %s: %s', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), $types[ $type ], $name );
	$body    = "Name: $name\nEmail: $email\nPhone: $phone\nOrganization: $org\nType: {$types[ $type ]}\n\n$msg";
	$ok      = wp_mail( $to, $subject, $body, array( 'Reply-To: ' . $name . ' <' . $email . '>' ) );

	wp_safe_redirect( add_query_arg( 'rp_form', $ok ? 'sent' : 'error', $back ) . '#contact' );
	exit;
}
add_action( 'admin_post_nopriv_rally_contact', 'rally_point_handle_form' );
add_action( 'admin_post_rally_contact', 'rally_point_handle_form' );
