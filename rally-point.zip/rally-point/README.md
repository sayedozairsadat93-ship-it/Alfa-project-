# Rally Point — WordPress block theme

Lightweight, no page builder, no plugins required. Requires WordPress 6.4+ and PHP 7.4+.

## Install
Dashboard → Appearance → Themes → Add New → Upload Theme → choose `rally-point.zip` → Activate.
On activation the theme creates demo pages (Home, About, Attractions, Sponsors, Contact, Privacy Policy, Terms) and sets Home as the front page. This happens once and never overwrites existing pages.

## Everyday editing
- **Edit the homepage:** Pages → Home → Edit. Open the List View (top-left icon); sections are named "Hero — Homepage", "Mission — Homepage", "Attractions — Homepage", "Partner Logos — Homepage", "CTA — Homepage", "Contact Form — Homepage".
- **Replace the hero image:** click the hero → toolbar → Replace → Media Library. Overlay strength: sidebar → Overlay → Opacity. Use a video instead: Replace → select a video file.
- **Replace any image:** click it → Replace → Media Library. Add link/alt text in the toolbar and sidebar.
- **Edit headings, text, buttons:** click and type. For a button link, select the button and use the link icon.
- **Add / remove / reorder cards:** select a card (List View is easiest) → use the ⋮ menu for Duplicate or Remove, or the arrows / drag to reorder.
- **Reorder, duplicate, remove sections:** select the section in List View → ⋮ menu → Duplicate / Remove; drag to reorder.
- **Hide a section without deleting it:** select the section → Styles → Hidden (not shown on site).
- **Replace the video:** click the video → paste a new YouTube or Vimeo link. For an uploaded video, delete the embed and add a Video block (set a poster image in its sidebar).
- **Partner logos:** each logo is an Image block in a grid. Replace, add a link, duplicate to add another, drag to reorder.
- **Navigation:** Appearance → Editor → Navigation (or click the menu in the header and edit).
- **Header / footer:** Appearance → Editor → Patterns → Template Parts.
- **Colors and fonts:** Appearance → Editor → Styles. Palette: Primary dark, Secondary dark, Accent/buttons, Button hover, Light background, White, Text, Muted, Border.
- **New pages:** Pages → Add New → click **+** → Patterns → "Rally Point sections". Stack sections in any order.
- **Landing page without header/footer:** in a page's sidebar choose the template "Landing page".

## Contact form
Shortcode `[rally_contact_form]` (already inside the Contact section). Sends to Settings → General → Administration Email Address. It has a nonce, honeypot, timing check, server-side validation and success/error messages. To use a different recipient add `add_filter('rally_point_form_recipient', fn() => 'you@example.com');` in a small plugin, or replace the shortcode block with any form plugin's block. For reliable delivery install an SMTP plugin.

## Structure
`theme.json` (design tokens) · `templates/` · `parts/` · `patterns/` · `assets/css` `assets/js` `assets/images` · `inc/contact-form.php`.
Fonts are system stacks (zero font requests). To use web fonts, upload them under Appearance → Editor → Styles → Typography.

## Notes
Placeholder images are labeled SVGs; replace them in the editor. No content or assets from any other website are included. Translation-ready (text domain `rally-point`, `/languages`).
