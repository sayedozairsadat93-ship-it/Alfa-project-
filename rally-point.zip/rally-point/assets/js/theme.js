(function () {
	var d = document, h = d.querySelector('.rp-header');
	d.documentElement.classList.add('rp-js');
	if (h) {
		var f = function () { h.classList.toggle('is-scrolled', window.scrollY > 24); };
		f(); window.addEventListener('scroll', f, { passive: true });
	}
	var els = d.querySelectorAll('.rp-reveal');
	if (!('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
		els.forEach(function (e) { e.classList.add('is-in'); }); return;
	}
	var io = new IntersectionObserver(function (en) {
		en.forEach(function (x) { if (x.isIntersecting) { x.target.classList.add('is-in'); io.unobserve(x.target); } });
	}, { rootMargin: '0px 0px -8% 0px' });
	els.forEach(function (e) { io.observe(e); });
})();
